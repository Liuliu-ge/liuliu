DROP TABLE IF EXISTS `web_config`;
create table `web_config` (
`k` varchar(32) NOT NULL,
`v` text NULL,
PRIMARY KEY  (`k`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `web_config` VALUES ('cache', '');
INSERT INTO `web_config` VALUES ('version', '6.6');
INSERT INTO `web_config` VALUES ('admin_user', 'midaili');
INSERT INTO `web_config` VALUES ('admin_pwd', 'admin');
INSERT INTO `web_config` VALUES ('style', '1');
INSERT INTO `web_config` VALUES ('sitename', '米代理米表管理系统');
INSERT INTO `web_config` VALUES ('title', '米代理米表管理系统');
INSERT INTO `web_config` VALUES ('keywords', '米代理米表管理系统 米表源码 米表展现系统网站源码 米表发布程序');
INSERT INTO `web_config` VALUES ('description', '米代理米表管理系统，适用于域名的展现与出售域名,以及快速增加域名、编辑域名不繁琐、无冗余，简洁而不简单，力求高效');
INSERT INTO `web_config` VALUES ('anounce', '');
INSERT INTO `web_config` VALUES ('kfqq', '872066666');
INSERT INTO `web_config` VALUES ('whois', '');
INSERT INTO `web_config` VALUES ('icp', '米代理号000001号');
INSERT INTO `web_config` VALUES ('modal', '');
INSERT INTO `web_config` VALUES ('gg', '米代理米表管理系统，适用于域名的展现与出售域名,以及快速增加域名、编辑域名不繁琐、无冗余，简洁而不简单，力求高效');
INSERT INTO `web_config` VALUES ('url', 'https://midai.li/');
INSERT INTO `web_config` VALUES ('bottom', '');

DROP TABLE IF EXISTS `web_dh`;
create table `web_dh` (
`id` int(1) NOT NULL AUTO_INCREMENT,
`url` varchar(255) NULL,
`ico` text NULL,
`info` text NULL,
`pay` text NULL,
`dz` text NULL,
`active` int(11) NOT NULL,
 PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8
