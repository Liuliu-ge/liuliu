<?php 

include("./includes/common.php");
include("./includes/txprotect.php");
if(!empty($conf['template']) && $conf['template'] != ""){
    $t = $conf['template'];
}else{
    $t = "default";
}
include 'template/'.$t.'/index.php';
?>