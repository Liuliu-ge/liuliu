
<!DOCTYPE HTML>

<html>
<head>
<meta charset="utf-8">
  <!--网页名称-->
<title><?php echo $conf['title']?></title>
<meta name="baidu-site-verification" content="b9lOcChmbf">
<meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no">
  <!--关键词-->
 <meta name="keywords" content="<?php echo $conf['keywords']?>">
 <!--描述-->
 <meta name="description" content="<?php echo $conf['description']?>">
 
 <meta property="og:image" content="<?php echo $conf['url']?>/favicon.ico">
<meta property="og:description" content="<?php echo $conf['keywords']?>" />
 <!--浏览器小图标，如有，请上传-->
<link rel="shortcut icon" href="favicon.ico">


    <!--    <link href="/static/media/favicons/favicon-192x192.png" rel="icon" sizes="192x192" type="image/png">-->
    <!--    <link href="/static/media/favicons/apple-touch-icon-180x180.png" rel="apple-touch-icon" sizes="180x180">-->
    <link href="../fonts.googleapis.com/css%3Ffamily=Poppins:300,400,500,600,700,800&amp;display=swap.css" rel="stylesheet">
    <link href="static/css/codebase.min-5.0.css" id="css-main" rel="stylesheet">
</head>
<body>
<div class="sidebar-dark side-scroll page-header-fixed page-header-glass main-content-boxed" id="page-container">
    <nav id="sidebar">
        <div class="sidebar-content">
            <div class="content-header justify-content-lg-center bg-black-10">
                <div>
                    <span class="smini-visible fw-bold tracking-wide fs-lg">
                      <span class="text-primary">t</span>
                    </span>
                    <a class="link-fx fw-bold tracking-wide mx-auto" href="https://liuliu.ge">
                      <span class="smini-hidden">
                        <i class="fa fa-fire text-primary"></i>
                        <span class="fs-4 text-dual"><?php echo $conf['title']?></span>
                      </span>
                    </a>
                </div>
                <div>
                    <button class="btn btn-sm btn-alt-danger d-lg-none" data-action="sidebar_close" data-toggle="layout"
                            type="button">
                        <i class="fa fa-fw fa-times"></i>
                    </button>
                </div>
            </div>
            <div class="js-sidebar-scroll">
                <div class="content-side content-side-full">
                    <ul class="nav-main">
                        <li class="nav-main-item">
                            <a class="nav-main-link active" href="#">
                                <i class="nav-main-link-icon fa fa-home"></i>
                                <span class="nav-main-link-name">首页</span>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </nav>
    <header id="page-header">
        <div class="content-header">
            <div class="space-x-1">
                <a class="link-fx fw-bold" href="/index.html">
                    <i class="fa fa-rocket text-primary"></i>
                    <span class="fs-4 text-dual"><?php echo $conf['title']?></span>
                </a>
            </div>
            <div class="d-flex align-items-center space-x-2">
                <ul class="nav-main nav-main-horizontal nav-main-hover d-none d-lg-block">
                    <li class="nav-main-item">
                        <a class="nav-main-link active" href="index.html#home">
                            <i class="nav-main-link-icon fa fa-home"></i>
                            <span class="nav-main-link-name">首页</span>
                        </a>
                    </li>
                </ul>
                <div class="dropdown d-inline-block">
                    
                    
                </div>
            </div>
        </div>
        <div class="overlay-header bg-primary" id="page-header-loader">
            <div class="content-header">
                <div class="w-100 text-center">
                    <i class="far fa-sun fa-spin text-white"></i>
                </div>
            </div>
        </div>
    </header>
    <main id="main-container">
        <div class="bg-primary-light overflow-hidden bg-image" id="#home">
            <div class="row">
                <div class="hero-inner">
                    <div class="content content-full text-center"><br><br>
                        <!--<h1 class="display-3 fw-bold text-white mb-2">
                                         </h1>-->
                        <h4 class="fw-medium text-white-50 mb-5">
                                                    </h4>
                                                <a class="btn btn-lg btn-alt-info fw-semibold me-1 mb-2 fs-sm" href="#">
                            <i class="si si-login opacity-50 me-1"></i> 登 录
                        </a>
                        <a class="btn btn-lg btn-primary fw-semibold mb-2 fs-sm" href="#">
                            <i class="si si-energy opacity-50 me-1"></i> 注 册
                        </a>
                                            </div>
                </div>
            </div>
        </div>
        <div class="bg-body-light" id="#features">
            <div class="content content-full">
                <div class="row">
                    <?php
$rs=$DB->query("SELECT * FROM web_dh WHERE active=1 order by id desc limit 7");
while($res = $DB->fetch($rs))
{?>   
                    <div class="col-md-6 col-xl-3 col-xm-2">
                        <a class="block block-rounded block-link-pop text-center" href="javascript:void(0)">
                            <div class="block-content block-content-full d-flex justify-content-between align-items-center">
                                <div>
                                    <img class="img-avatar"
                                         src="<?php echo $res['ico'];?>"
                                         alt="">
                                </div>
                                <div class="text-end">
                                    <div class="fw-semibold mb-1">
                                        <?php echo $res['url'];?>
                                    </div>
                                    <div class="fs-sm text-muted">
                                        <?php echo $res['info'];?>
                                    </div>
                                    <div class="fs-sm text-muted jiage">
                                        价格：<?php echo $res['pay'];?>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    
                    
            <?php }?>     
                  </a>
                    </div>

            </div>
        </div>
                   </br>
                   
                <div class="bg-body-light" id="#features">
            <div class="content content-full">
                <div class="row">  
                  <?php
$rs=$DB->query("SELECT * FROM web_dh WHERE active=0 order by id desc limit 7");
while($res = $DB->fetch($rs))
{?>   
                    <div class="col-md-6 col-xl-3 col-xm-2">
                        <a class="block block-rounded block-link-pop text-center" href="javascript:void(0)">
                            <div class="block-content block-content-full d-flex justify-content-between align-items-center">
                                <div>
                                    <img class="img-avatar"
                                         src="<?php echo $res['ico'];?>"
                                         alt="">
                                </div>
                                <div class="text-end">
                                    <div class="fw-semibold mb-1">
                                        <?php echo $res['url'];?>
                                    </div>
                                    <div class="fs-sm text-muted">
                                        <?php echo $res['info'];?>
                                    </div>
                                    <div class="fs-sm text-muted jiage">
                                        价格：<?php echo $res['pay'];?>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    
                    
            <?php }?>     
                  </a>
                </div>

            </div>
        </div>
        
        
        <div class="bg-body-extra-light">
            <div class="content content-full pt-7">
                <div class="py-4 text-center">
                    <div class="position-relative">
                        <h2 class="fw-bold mb-2 text-center">
                            域名交易 <span class="text-primary">流程</span>
                        </h2>
                        
         <h5> 挑选域名→联系卖家→支付费用→过户域名→完成交易🤝</h5>

                    </div>
                    
                </div>
            </div>
        </div>

        <div class="bg-body-light">
            <div class="content content-full">
                <div class="py-5 text-center">

                    <h3 class="fw-bold mb-2">坚持你的梦想</h3>
                    <h4 class="fw-normal text-muted mb-4">永远相信美好的事情 即将发生</h4>
                    <a class="btn btn-alt-primary" href="https://fupin.ru">赞助我们</a>
                </div>
            </div>
        </div>

    </main>

    <footer class="bg-body-extra-light" id="page-footer">
        <div class="content content-full">
            <div class="row g-0 fs-sm border-top pt-3">
                <div class="col-sm-6 order-sm-2 py-1 text-center text-sm-end">
                    &copy; <span data-toggle="year-copy"></span> <a class="fw-semibold" href="https://www.liuliu.ge" target="_blank">六六哥网络工作室</a>
                                  <!--<i class="fa fa-heart text-danger"></i> by <a class="fw-semibold" href="https://www.liuliu.ge" target="_blank">Liuliu-Studio</a>-->      

                </div>
                <div class="col-sm-6 order-sm-1 py-1 text-center text-sm-start">
                    <a href="" target="_blank" class="text-muted fw-semibold">米联盟号10001号</a>
                </div>
            </div>
        </div>
    </footer>

</div>

<script src="/static/js/codebase.app.min-5.0.js"></script>

</body>
</html>