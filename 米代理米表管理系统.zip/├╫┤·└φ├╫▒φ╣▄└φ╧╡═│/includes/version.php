<?php 

define('VERSION', '66');
?>